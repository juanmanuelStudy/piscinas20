package com.spring.mybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBatisBtbPpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBatisBtbPpApplication.class, args);
	}
}
