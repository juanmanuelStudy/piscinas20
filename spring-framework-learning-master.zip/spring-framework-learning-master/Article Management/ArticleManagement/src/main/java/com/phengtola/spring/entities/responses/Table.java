package com.phengtola.spring.entities.responses;

public class Table {
	
	public static final String ARTICLE = "Articles";
	public static final String ARTICLE_TAG = "Article_tags";
	public static final String CATEGORIES = "Categories";
	public static final String COMMENTS = "Comments";
	public static final String FILES = "Files";
	public static final String PERMISSIONS = "Permission";
	public static final String ROLE_PERMISSION = "Role_permission";
	public static final String ROLES = "Roles";
	public static final String TAGS = "Tags";
	public static final String USER_ROLES = "User_roles";
	public static final String USERS = "Users";


	
}
