package com.phengtola.spring.controllers.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * @author Tola Created Date: 2017/07/03
 *
 */

@RestController
@RequestMapping("/v1/api/category")
public class CategoryRController {


}
