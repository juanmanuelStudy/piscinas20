package com.springdemy.thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafCustomLayoutAdminTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafCustomLayoutAdminTemplateApplication.class, args);
	}
}
