package com.spring.thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtbPp120617ThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtbPp120617ThymeleafApplication.class, args);
	}
}
