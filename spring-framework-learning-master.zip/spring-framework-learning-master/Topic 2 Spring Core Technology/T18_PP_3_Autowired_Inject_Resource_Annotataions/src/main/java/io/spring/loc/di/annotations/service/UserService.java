package io.spring.loc.di.annotations.service;

import io.spring.loc.di.annotations.model.User;

public interface UserService {
	
	public User findUserByID();

}
