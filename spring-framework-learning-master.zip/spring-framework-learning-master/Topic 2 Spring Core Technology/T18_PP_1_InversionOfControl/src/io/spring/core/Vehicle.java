package io.spring.core;

public interface Vehicle {
	
	void startEngine(String type);

}
