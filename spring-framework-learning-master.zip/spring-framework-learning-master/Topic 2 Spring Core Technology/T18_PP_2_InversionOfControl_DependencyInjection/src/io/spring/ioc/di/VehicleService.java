package io.spring.ioc.di;

public interface VehicleService {

	void startEngine(String type);
	
}
