package com.hrd.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T19PpPojoProgrammingModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(T19PpPojoProgrammingModelApplication.class, args);
	}
}
