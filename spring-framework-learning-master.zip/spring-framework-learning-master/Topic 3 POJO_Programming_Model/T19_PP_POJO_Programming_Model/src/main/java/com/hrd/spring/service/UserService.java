package com.hrd.spring.service;

import com.hrd.spring.model.User;

public interface UserService {

	public User findUserById(int id);
	
}

